    <div class="fixed bottom-0 w-full bg-gray-900 border-t border-red-900 flex justify-around py-3 z-50">
        <a href="index.php" class="text-gray-400 hover:text-red-400 text-center flex flex-col items-center">
            <i class="fas fa-tachometer-alt text-xl"></i><span class="text-xs mt-1">Dash</span>
        </a>
        <a href="sellers.php" class="text-gray-400 hover:text-red-400 text-center flex flex-col items-center">
            <i class="fas fa-store text-xl"></i><span class="text-xs mt-1">Sellers</span>
        </a>
        <a href="products.php" class="text-gray-400 hover:text-red-400 text-center flex flex-col items-center">
            <i class="fas fa-box text-xl"></i><span class="text-xs mt-1">Items</span>
        </a>
        <a href="commission.php" class="text-gray-400 hover:text-red-400 text-center flex flex-col items-center">
            <i class="fas fa-chart-line text-xl"></i><span class="text-xs mt-1">Revenue</span>
        </a>
        <a href="settings.php" class="text-gray-400 hover:text-red-400 text-center flex flex-col items-center">
            <i class="fas fa-cog text-xl"></i><span class="text-xs mt-1">Settings</span>
        </a>
    </div>
</body>
</html>
