<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// Total stats
$total_revenue = $pdo->query("SELECT SUM(total_price) FROM orders")->fetchColumn() ?: 0;
$total_commission = $pdo->query("SELECT SUM(commission) FROM order_items")->fetchColumn() ?: 0;

// Recent commission events
$stmt = $pdo->query("SELECT oi.commission, oi.price, oi.quantity, p.name, o.created_at 
                     FROM order_items oi 
                     JOIN products p ON oi.product_id = p.id 
                     JOIN orders o ON oi.order_id = o.id 
                     ORDER BY o.created_at DESC LIMIT 50");
$commissions = $stmt->fetchAll();

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <h1 class="text-2xl font-bold text-red-500 mb-6">Platform Revenue</h1>
    
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="bg-gray-800 p-4 rounded-lg text-center border border-gray-700">
            <p class="text-xs text-gray-400 uppercase">Gross Sales</p>
            <p class="text-xl font-bold">₹<?= number_format($total_revenue, 2) ?></p>
        </div>
        <div class="bg-red-900 p-4 rounded-lg text-center border border-red-700 shadow-lg shadow-red-900/50">
            <p class="text-xs text-red-200 uppercase">Net Commission</p>
            <p class="text-xl font-bold text-white">₹<?= number_format($total_commission, 2) ?></p>
        </div>
    </div>

    <h2 class="font-bold text-gray-300 mb-3 border-b border-gray-700 pb-2">Recent Earnings</h2>
    <div class="space-y-3">
        <?php foreach($commissions as $c): ?>
        <div class="bg-gray-800 p-3 rounded flex justify-between items-center border-l-2 border-red-500">
            <div>
                <p class="text-sm font-bold truncate w-40"><?= htmlspecialchars($c['name']) ?></p>
                <p class="text-xs text-gray-400"><?= date('d M Y, h:i A', strtotime($c['created_at'])) ?></p>
            </div>
            <div class="text-right">
                <p class="text-xs text-gray-400">Sale: ₹<?= number_format($c['price'] * $c['quantity'], 2) ?></p>
                <p class="text-green-400 font-bold text-sm">+₹<?= number_format($c['commission'], 2) ?></p>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require 'common/bottom.php'; ?>
