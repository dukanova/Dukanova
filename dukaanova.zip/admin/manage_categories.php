<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    if (isset($_POST['add_category'])) {
        $name = trim($_POST['name']);
        $slug = strtolower(str_replace(' ', '-', $name)) . '-' . rand(100,999);
        $parent_id = (int)$_POST['parent_id'];
        
        $stmt = $pdo->prepare("INSERT INTO categories (name, slug, parent_id) VALUES (?, ?, ?)");
        if ($stmt->execute([$name, $slug, $parent_id])) {
            $msg = "<p class='text-green-400 mb-4'>Category added successfully.</p>";
        }
    } elseif (isset($_POST['delete_category'])) {
        $id = (int)$_POST['delete_id'];
        $pdo->prepare("DELETE FROM categories WHERE id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM product_category_map WHERE category_id = ?")->execute([$id]);
        $msg = "<p class='text-red-400 mb-4'>Category deleted.</p>";
    }
}

// Fetch Categories
$categories = $pdo->query("SELECT c1.*, c2.name as parent_name FROM categories c1 LEFT JOIN categories c2 ON c1.parent_id = c2.id ORDER BY c1.parent_id ASC, c1.name ASC")->fetchAll();

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <div class="flex items-center mb-6">
        <a href="index.php" class="text-gray-400 mr-3"><i class="fas fa-arrow-left text-xl"></i></a>
        <h1 class="text-2xl font-bold text-red-500">Manage Categories</h1>
    </div>
    
    <?= $msg ?>

    <div class="bg-gray-800 p-5 rounded-lg mb-6 border border-gray-700">
        <h3 class="font-bold mb-4 text-white">Create New Category</h3>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            <input type="hidden" name="add_category" value="1">
            
            <input type="text" name="name" placeholder="Category Name" required class="w-full p-3 bg-gray-900 border border-gray-600 rounded text-white focus:border-red-500 outline-none">
            
            <select name="parent_id" class="w-full p-3 bg-gray-900 border border-gray-600 rounded text-white focus:border-red-500 outline-none">
                <option value="0">-- Top Level Category (No Parent) --</option>
                <?php foreach($categories as $c): ?>
                    <?php if($c['parent_id'] == 0): ?>
                        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            
            <button type="submit" class="w-full bg-red-600 hover:bg-red-700 p-3 rounded font-bold transition">Save Category</button>
        </form>
    </div>

    <div class="space-y-3">
        <h3 class="font-bold text-gray-400 border-b border-gray-700 pb-2">Existing Categories</h3>
        <?php foreach($categories as $c): ?>
        <div class="bg-gray-800 p-3 rounded flex justify-between items-center border-l-4 border-red-500">
            <div>
                <p class="font-bold text-sm"><?= htmlspecialchars($c['name']) ?></p>
                <?php if($c['parent_name']): ?>
                    <p class="text-xs text-gray-400">Subcategory of: <?= htmlspecialchars($c['parent_name']) ?></p>
                <?php else: ?>
                    <p class="text-xs text-indigo-400">Top Level</p>
                <?php endif; ?>
            </div>
            <form method="POST" onsubmit="return confirm('Delete this category? Products mapped to it will lose this category tag.');">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <input type="hidden" name="delete_category" value="1">
                <input type="hidden" name="delete_id" value="<?= $c['id'] ?>">
                <button type="submit" class="text-red-400 hover:text-red-200"><i class="fas fa-trash"></i></button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require 'common/bottom.php'; ?>
