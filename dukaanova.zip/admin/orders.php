<?php
require '../common/config.php';

// Fetch all order items globally
$stmt = $pdo->query("
    SELECT oi.*, p.name as product_name, s.store_name, o.created_at, u.username as customer_name 
    FROM order_items oi 
    JOIN products p ON oi.product_id = p.id 
    JOIN sellers s ON oi.seller_id = s.id
    JOIN orders o ON oi.order_id = o.id 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();

require '../common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen">
    <div class="flex items-center mb-6">
        <a href="index.php" class="text-gray-400 mr-3"><i class="fas fa-arrow-left text-xl"></i></a>
        <h1 class="text-2xl font-bold text-red-500">Platform Orders</h1>
    </div>

    <div class="space-y-4 overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-800 text-gray-400 text-sm">
                    <th class="p-3 rounded-tl">Order ID</th>
                    <th class="p-3">Customer</th>
                    <th class="p-3">Store</th>
                    <th class="p-3">Item</th>
                    <th class="p-3">Amount</th>
                    <th class="p-3 rounded-tr text-green-400">Comm. (2%)</th>
                </tr>
            </thead>
            <tbody class="text-sm">
                <?php foreach($orders as $o): ?>
                <tr class="border-b border-gray-800 hover:bg-gray-800">
                    <td class="p-3">#<?= $o['order_id'] ?></td>
                    <td class="p-3"><?= htmlspecialchars($o['customer_name']) ?></td>
                    <td class="p-3 text-indigo-400"><?= htmlspecialchars($o['store_name']) ?></td>
                    <td class="p-3"><?= htmlspecialchars($o['product_name']) ?> (x<?= $o['quantity'] ?>)</td>
                    <td class="p-3">₹<?= number_format($o['price'] * $o['quantity'], 2) ?></td>
                    <td class="p-3 text-green-400 font-bold">₹<?= number_format($o['commission'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
