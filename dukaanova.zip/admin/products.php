<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$delete_id]);
    $msg = "<p class='text-green-400 mb-4'>Product deleted successfully.</p>";
}

$stmt = $pdo->query("SELECT p.*, s.store_name FROM products p JOIN sellers s ON p.seller_id = s.id ORDER BY p.created_at DESC");
$products = $stmt->fetchAll();

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <h1 class="text-2xl font-bold text-red-500 mb-6">Manage Products</h1>
    <?= $msg ?>
    
    <div class="space-y-4">
        <?php foreach($products as $p): ?>
        <div class="bg-gray-800 p-3 rounded flex justify-between items-center border border-gray-700">
            <div>
                <h3 class="font-bold text-sm"><?= htmlspecialchars($p['name']) ?></h3>
                <p class="text-xs text-indigo-400">Store: <?= htmlspecialchars($p['store_name']) ?></p>
                <p class="text-sm mt-1 text-gray-300">₹<?= number_format($p['price'], 2) ?> | Stock: <?= $p['stock'] ?></p>
            </div>
            <form method="POST" onsubmit="return confirm('Delete this product globally?');">
                <input type="hidden" name="delete_id" value="<?= $p['id'] ?>">
                <button type="submit" class="bg-red-900 text-red-200 hover:bg-red-700 px-3 py-2 rounded transition"><i class="fas fa-trash-alt"></i></button>
            </form>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require 'common/bottom.php'; ?>
