<?php
require '../common/config.php';
// Admin Verification (Assuming you have some session check, adding basic protection)
if (!isset($_SESSION['user_id'])) { header("Location: ../login.php"); exit; }

// Fetch All Sellers with their User Login Email
$stmt = $pdo->query("
    SELECT s.*, u.email as login_email, u.username as owner_name, u.created_at as joined_date 
    FROM sellers s 
    JOIN users u ON s.user_id = u.id 
    WHERE u.role = 'seller'
    ORDER BY u.created_at DESC
");
$all_sellers = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sellers - Dukaanova Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style> body { font-family: 'Inter', sans-serif; background-color: #f3f4f6; } </style>
</head>
<body class="antialiased">

    <header class="bg-gray-900 text-white px-6 py-4 flex items-center justify-between shadow-md">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 bg-indigo-500 rounded flex items-center justify-center font-bold">D</div>
            <h1 class="text-xl font-black tracking-widest uppercase">Admin Panel</h1>
        </div>
        <a href="../index.php" class="text-sm font-bold text-gray-400 hover:text-white transition"><i class="fas fa-external-link-alt mr-2"></i>Visit Marketplace</a>
    </header>

    <main class="max-w-7xl mx-auto px-4 py-8">
        
        <div class="flex items-center justify-between mb-8">
            <div>
                <h2 class="text-3xl font-black text-gray-900 tracking-tight">Registered Sellers</h2>
                <p class="text-sm text-gray-500 mt-1">Manage and view all business accounts on Dukaanova.</p>
            </div>
            <div class="bg-white px-4 py-2 border border-gray-200 rounded-lg shadow-sm font-bold text-gray-700">
                Total Sellers: <span class="text-indigo-600"><?= count($all_sellers) ?></span>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full whitespace-nowrap">
                    <thead class="bg-gray-50 border-b border-gray-200">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-black text-gray-500 uppercase tracking-widest">Store Info</th>
                            <th class="px-6 py-4 text-left text-xs font-black text-gray-500 uppercase tracking-widest">Contact Details</th>
                            <th class="px-6 py-4 text-left text-xs font-black text-gray-500 uppercase tracking-widest">Address</th>
                            <th class="px-6 py-4 text-left text-xs font-black text-gray-500 uppercase tracking-widest">Joined On</th>
                            <th class="px-6 py-4 text-center text-xs font-black text-gray-500 uppercase tracking-widest">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        <?php if(empty($all_sellers)): ?>
                            <tr><td colspan="5" class="px-6 py-12 text-center text-gray-500 font-bold">No sellers registered yet.</td></tr>
                        <?php else: ?>
                            <?php foreach($all_sellers as $s): ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-full bg-gray-100 border border-gray-200 flex items-center justify-center overflow-hidden shrink-0">
                                            <?php if(!empty($s['logo_image'])): ?>
                                                <img src="../uploads/<?= htmlspecialchars($s['logo_image']) ?>" class="w-full h-full object-cover">
                                            <?php else: ?>
                                                <span class="font-bold text-gray-400"><?= strtoupper(substr($s['store_name'], 0, 1)) ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <p class="font-bold text-gray-900"><?= htmlspecialchars($s['store_name']) ?></p>
                                            <p class="text-[10px] text-gray-500 uppercase tracking-widest">Owner: <?= htmlspecialchars($s['owner_name']) ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <p class="text-sm font-bold text-gray-800"><i class="fas fa-phone-alt text-gray-400 mr-2 text-xs"></i><?= htmlspecialchars($s['mobile_number'] ?? 'N/A') ?></p>
                                    <p class="text-xs text-gray-500 mt-1"><i class="fas fa-envelope text-gray-400 mr-2"></i><?= htmlspecialchars($s['business_email'] ?? $s['login_email']) ?></p>
                                </td>
                                <td class="px-6 py-4">
                                    <p class="text-xs text-gray-600 whitespace-normal w-48 leading-relaxed">
                                        <?= htmlspecialchars($s['office_address'] ?? 'Not provided') ?>
                                    </p>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="bg-green-100 text-green-700 px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-widest">
                                        <?= date('M d, Y', strtotime($s['joined_date'])) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <a href="../store/store.php?name=<?= urlencode($s['store_slug']) ?>" target="_blank" class="text-indigo-600 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded text-xs font-bold transition">View Store</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

</body>
</html>
