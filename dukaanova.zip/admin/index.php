<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

// Comprehensive SaaS Analytics
$total_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$total_stores = $pdo->query("SELECT COUNT(*) FROM sellers")->fetchColumn();
$total_products = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();

// Financials
$gross_sales = $pdo->query("SELECT SUM(total_price) FROM orders")->fetchColumn() ?: 0;
$platform_revenue = $pdo->query("SELECT SUM(commission) FROM order_items")->fetchColumn() ?: 0;

// Payouts
$pending_payouts_count = $pdo->query("SELECT COUNT(*) FROM payout_requests WHERE status = 'Pending'")->fetchColumn();
$pending_payouts_amount = $pdo->query("SELECT SUM(amount) FROM payout_requests WHERE status = 'Pending'")->fetchColumn() ?: 0;

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <div class="flex items-center justify-between mb-6">
        <h1 class="text-2xl font-bold text-red-500">Platform Command Center</h1>
        <a href="settings.php" class="text-gray-400 hover:text-white"><i class="fas fa-cog text-xl"></i></a>
    </div>
    
    <h2 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Financial Overview</h2>
    <div class="grid grid-cols-2 gap-4 mb-6">
        <div class="bg-gray-800 p-5 rounded-xl border border-gray-700 shadow-lg relative overflow-hidden">
            <div class="absolute top-0 right-0 p-3 opacity-10"><i class="fas fa-chart-line text-6xl text-white"></i></div>
            <h3 class="text-gray-400 text-xs font-bold uppercase">Gross Market Sales</h3>
            <p class="text-2xl font-bold mt-1 text-white">₹<?= number_format($gross_sales, 2) ?></p>
        </div>
        
        <div class="bg-gradient-to-br from-red-900 to-gray-900 p-5 rounded-xl border border-red-700 shadow-lg shadow-red-900/30 relative overflow-hidden">
            <div class="absolute top-0 right-0 p-3 opacity-10"><i class="fas fa-wallet text-6xl text-white"></i></div>
            <h3 class="text-red-300 text-xs font-bold uppercase">Platform Net Profit</h3>
            <p class="text-2xl font-bold mt-1 text-white">₹<?= number_format($platform_revenue, 2) ?></p>
        </div>
    </div>

    <?php if($pending_payouts_count > 0): ?>
    <div class="bg-yellow-900 bg-opacity-30 border border-yellow-700 p-4 rounded-lg mb-6 flex justify-between items-center">
        <div>
            <p class="text-yellow-400 font-bold text-sm"><i class="fas fa-exclamation-triangle mr-1"></i> Action Required</p>
            <p class="text-gray-300 text-xs mt-1"><?= $pending_payouts_count ?> sellers are requesting payouts totaling <span class="font-bold text-white">₹<?= number_format($pending_payouts_amount, 2) ?></span></p>
        </div>
        <a href="manage_payouts.php" class="bg-yellow-600 hover:bg-yellow-700 text-white text-xs font-bold px-3 py-2 rounded transition">Review</a>
    </div>
    <?php endif; ?>

    <h2 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Network Stats</h2>
    <div class="grid grid-cols-3 gap-3 mb-8">
        <div class="bg-gray-800 p-3 rounded-lg text-center border border-gray-700">
            <i class="fas fa-users text-xl text-indigo-400 mb-1 block"></i>
            <p class="text-lg font-bold text-white"><?= $total_users ?></p>
            <p class="text-[10px] text-gray-400 uppercase">Users</p>
        </div>
        <div class="bg-gray-800 p-3 rounded-lg text-center border border-gray-700">
            <i class="fas fa-store text-xl text-green-400 mb-1 block"></i>
            <p class="text-lg font-bold text-white"><?= $total_stores ?></p>
            <p class="text-[10px] text-gray-400 uppercase">Stores</p>
        </div>
        <div class="bg-gray-800 p-3 rounded-lg text-center border border-gray-700">
            <i class="fas fa-box-open text-xl text-orange-400 mb-1 block"></i>
            <p class="text-lg font-bold text-white"><?= $total_products ?></p>
            <p class="text-[10px] text-gray-400 uppercase">Items</p>
        </div>
    </div>

    <h2 class="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Management Modules</h2>
    <div class="grid grid-cols-2 gap-3">
        <a href="manage_categories.php" class="bg-gray-800 p-4 rounded-lg border border-gray-700 hover:border-red-500 transition flex items-center">
            <div class="w-10 h-10 rounded bg-gray-900 flex items-center justify-center mr-3 text-red-400"><i class="fas fa-tags"></i></div>
            <div>
                <p class="font-bold text-sm text-white">Categories</p>
                <p class="text-[10px] text-gray-400">Global Taxonomy</p>
            </div>
        </a>
        <a href="manage_payouts.php" class="bg-gray-800 p-4 rounded-lg border border-gray-700 hover:border-red-500 transition flex items-center">
            <div class="w-10 h-10 rounded bg-gray-900 flex items-center justify-center mr-3 text-green-400"><i class="fas fa-money-check-alt"></i></div>
            <div>
                <p class="font-bold text-sm text-white">Payouts</p>
                <p class="text-[10px] text-gray-400">Seller Withdrawals</p>
            </div>
        </a>
        <a href="sellers.php" class="bg-gray-800 p-4 rounded-lg border border-gray-700 hover:border-red-500 transition flex items-center">
            <div class="w-10 h-10 rounded bg-gray-900 flex items-center justify-center mr-3 text-blue-400"><i class="fas fa-store-alt"></i></div>
            <div>
                <p class="font-bold text-sm text-white">Sellers</p>
                <p class="text-[10px] text-gray-400">Manage Stores</p>
            </div>
        </a>
        <a href="products.php" class="bg-gray-800 p-4 rounded-lg border border-gray-700 hover:border-red-500 transition flex items-center">
            <div class="w-10 h-10 rounded bg-gray-900 flex items-center justify-center mr-3 text-orange-400"><i class="fas fa-search"></i></div>
            <div>
                <p class="font-bold text-sm text-white">Moderation</p>
                <p class="text-[10px] text-gray-400">Audit Products</p>
            </div>
        </a>
    </div>
</div>
<?php require 'common/bottom.php'; ?>
