<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    verify_csrf();
    $payout_id = (int)$_POST['payout_id'];
    $action = $_POST['action']; // 'approve' or 'reject'
    
    // Fetch payout details
    $stmt = $pdo->prepare("SELECT pr.*, s.user_id FROM payout_requests pr JOIN sellers s ON pr.seller_id = s.id WHERE pr.id = ? AND pr.status = 'Pending'");
    $stmt->execute([$payout_id]);
    $request = $stmt->fetch();

    if ($request) {
        if ($action == 'approve') {
            // In a real world, you'd integrate RazorpayX / Stripe Payouts here.
            // For now, we manually mark it as Paid.
            $pdo->prepare("UPDATE payout_requests SET status = 'Paid' WHERE id = ?")->execute([$payout_id]);
            $msg = "<p class='text-green-400 mb-4 font-bold'>Payout marked as Paid.</p>";
        } elseif ($action == 'reject') {
            $pdo->beginTransaction();
            try {
                // Refund the amount back to seller's wallet
                $pdo->prepare("UPDATE users SET wallet_balance = wallet_balance + ? WHERE id = ?")->execute([$request['amount'], $request['user_id']]);
                // Mark Rejected
                $pdo->prepare("UPDATE payout_requests SET status = 'Rejected' WHERE id = ?")->execute([$payout_id]);
                $pdo->commit();
                $msg = "<p class='text-red-400 mb-4 font-bold'>Payout rejected. Funds returned to seller wallet.</p>";
            } catch (Exception $e) {
                $pdo->rollBack();
                $msg = "<p class='text-red-400 mb-4'>Error processing rejection.</p>";
            }
        }
    }
}

// Fetch all payouts
$payouts = $pdo->query("SELECT pr.*, s.store_name, u.username, u.email 
                        FROM payout_requests pr 
                        JOIN sellers s ON pr.seller_id = s.id 
                        JOIN users u ON s.user_id = u.id 
                        ORDER BY FIELD(pr.status, 'Pending', 'Paid', 'Rejected'), pr.created_at DESC")->fetchAll();

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <div class="flex items-center mb-6">
        <a href="index.php" class="text-gray-400 mr-3"><i class="fas fa-arrow-left text-xl"></i></a>
        <h1 class="text-2xl font-bold text-red-500">Manage Payouts</h1>
    </div>
    
    <?= $msg ?>

    <div class="space-y-4">
        <?php foreach($payouts as $p): ?>
        <div class="bg-gray-800 p-4 rounded-lg border <?= $p['status'] == 'Pending' ? 'border-yellow-500 shadow-yellow-900/20' : 'border-gray-700' ?> shadow-lg">
            <div class="flex justify-between items-start mb-3 border-b border-gray-700 pb-3">
                <div>
                    <h3 class="font-bold text-lg text-white">₹<?= number_format($p['amount'], 2) ?></h3>
                    <p class="text-xs text-gray-400">Request #<?= $p['id'] ?> • <?= date('d M Y, h:i A', strtotime($p['created_at'])) ?></p>
                </div>
                <span class="px-2 py-1 rounded text-xs font-bold bg-gray-900 <?= $p['status'] == 'Pending' ? 'text-yellow-400' : ($p['status'] == 'Paid' ? 'text-green-400' : 'text-red-400') ?>">
                    <?= htmlspecialchars($p['status']) ?>
                </span>
            </div>
            
            <div class="mb-4">
                <p class="text-sm font-bold text-indigo-400"><i class="fas fa-store"></i> <?= htmlspecialchars($p['store_name']) ?></p>
                <p class="text-xs text-gray-400">User: <?= htmlspecialchars($p['username']) ?> (<?= htmlspecialchars($p['email']) ?>)</p>
            </div>

            <?php if($p['status'] == 'Pending'): ?>
            <div class="flex space-x-2">
                <form method="POST" class="flex-1">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="payout_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="action" value="approve">
                    <button type="submit" onclick="return confirm('Did you actually transfer the money? Mark as Paid?');" class="w-full bg-green-600 hover:bg-green-700 p-2 rounded text-sm font-bold transition">Mark Paid</button>
                </form>
                <form method="POST" class="flex-1">
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                    <input type="hidden" name="payout_id" value="<?= $p['id'] ?>">
                    <input type="hidden" name="action" value="reject">
                    <button type="submit" onclick="return confirm('Reject this and refund the seller?');" class="w-full bg-red-900 text-red-300 hover:bg-red-800 p-2 rounded text-sm font-bold transition">Reject & Refund</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php require 'common/bottom.php'; ?>
