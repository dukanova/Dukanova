<?php
require '../common/config.php';
if (!isset($_SESSION['admin_id'])) { header("Location: login.php"); exit; }

$admin_id = $_SESSION['admin_id'];
$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['update_admin'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $hash = password_hash($password, PASSWORD_DEFAULT);
        
        $pdo->prepare("UPDATE admin SET username = ?, password = ? WHERE id = ?")
            ->execute([$username, $hash, $admin_id]);
        $msg = "<p class='text-green-400 mb-4'>Admin credentials updated!</p>";
    } elseif (isset($_POST['logout'])) {
        unset($_SESSION['admin_id']);
        header("Location: login.php");
        exit;
    }
}

$admin = $pdo->prepare("SELECT username FROM admin WHERE id = ?");
$admin->execute([$admin_id]);
$current_admin = $admin->fetchColumn();

require 'common/header.php';
?>
<div class="p-4 bg-gray-900 min-h-screen pb-24">
    <h1 class="text-2xl font-bold text-red-500 mb-6">Admin Settings</h1>
    <?= $msg ?>
    
    <div class="bg-gray-800 p-5 rounded-lg mb-6 border border-gray-700">
        <h3 class="font-bold mb-4 text-white">Update Credentials</h3>
        <form method="POST" class="space-y-4">
            <input type="hidden" name="update_admin" value="1">
            <div>
                <label class="text-xs text-gray-400">Admin Username</label>
                <input type="text" name="username" value="<?= htmlspecialchars($current_admin) ?>" required class="w-full p-3 bg-gray-900 rounded text-white mt-1 border border-gray-600 focus:border-red-500 outline-none">
            </div>
            <div>
                <label class="text-xs text-gray-400">New Password</label>
                <input type="password" name="password" required class="w-full p-3 bg-gray-900 rounded text-white mt-1 border border-gray-600 focus:border-red-500 outline-none">
            </div>
            <button type="submit" class="w-full bg-red-600 hover:bg-red-700 p-3 rounded font-bold transition">Save Changes</button>
        </form>
    </div>

    <form method="POST">
        <input type="hidden" name="logout" value="1">
        <button type="submit" class="w-full bg-gray-800 border border-red-900 text-red-400 p-3 rounded font-bold hover:bg-gray-700 transition">
            <i class="fas fa-sign-out-alt mr-2"></i> Log Out
        </button>
    </form>
</div>
<?php require 'common/bottom.php'; ?>
