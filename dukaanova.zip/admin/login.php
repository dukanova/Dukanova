<?php
require '../common/config.php';

$msg = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM admin WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_id'] = $admin['id'];
        header("Location: index.php");
        exit;
    } else {
        $msg = "Invalid admin credentials!";
    }
}
require '../common/header.php';
?>
<div class="p-6 min-h-screen bg-gray-900 flex flex-col justify-center">
    <div class="text-center mb-8">
        <i class="fas fa-shield-alt text-5xl text-red-500 mb-4"></i>
        <h1 class="text-3xl font-bold text-white">Admin Login</h1>
    </div>
    
    <p class="text-red-400 text-center mb-4"><?= $msg ?></p>
    
    <div class="bg-gray-800 p-6 rounded-lg shadow-xl border border-gray-700">
        <form method="POST" class="space-y-4">
            <div>
                <label class="text-gray-400 text-sm block mb-1">Username</label>
                <input type="text" name="username" required class="w-full p-3 bg-gray-900 border border-gray-600 rounded text-white focus:outline-none focus:border-red-500">
            </div>
            <div>
                <label class="text-gray-400 text-sm block mb-1">Password</label>
                <input type="password" name="password" required class="w-full p-3 bg-gray-900 border border-gray-600 rounded text-white focus:outline-none focus:border-red-500">
            </div>
            <button type="submit" class="w-full bg-red-600 hover:bg-red-700 p-3 rounded font-bold transition duration-200 mt-4">Secure Login</button>
        </form>
    </div>
</div>
